import React, { useState } from 'react';
import './App.css';

function App() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Task Added!\nTitle: ${title}\nDescription: ${description}`);
    setTitle('');
    setDescription('');
  };

  return (
    <div className="App">
      <img src="/logo192.png" alt="DevOps Insiders" className="logo" />
      <h1>Anoop's ToDo App</h1>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" 
          placeholder="Title" 
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required 
        />
        <textarea 
          placeholder="Description" 
          rows="4"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required 
        />
        <button type="submit">Add Task</button>
      </form>
    </div>
  );
}

export default App;
