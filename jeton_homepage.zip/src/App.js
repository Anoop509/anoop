import React, { useEffect } from 'react';
import './App.css';

function App() {
  useEffect(() => {
    console.log('App component mounted');
  }, []);

  const handleSignUpClick = () => {
    console.log('Sign Up Now button clicked');
  };

  const handleNavClick = (section) => {
    console.log(`Navigated to ${section}`);
  };

  return (
    <div className="container">
      {console.log('Rendering App component')}
      <header className="header">
        <div className="logo">🔶 Jeton</div>
        <nav>
          <a href="#features" onClick={() => handleNavClick('Features')}>Features</a>
          <a href="#business" onClick={() => handleNavClick('Business')}>Business</a>
          <a href="#help" onClick={() => handleNavClick('Help')}>Help</a>
        </nav>
      </header>

      <main className="hero">
        {console.log('Rendering hero section')}
        <h1>All in one payment solution</h1>
        <p>
          Sign up for an account to pay online, send money, and receive payments.
        </p>
        <button onClick={handleSignUpClick}>Sign Up Now</button>
      </main>

      <footer className="footer">
        {console.log('Rendering footer')}
        © 2025 Jeton. All rights reserved.
      </footer>
    </div>
  );
}

export default App;
